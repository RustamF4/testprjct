#!/bin/bash

php artisan config:cache

# Start Apache service
apache2-foreground
