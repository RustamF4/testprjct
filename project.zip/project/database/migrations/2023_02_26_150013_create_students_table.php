<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('name')->index();
            $table->string('surname')->index();
            $table->string('middle_name')->nullable();
            $table->string('category')->nullable();
            $table->string('phone');
            $table->string('info')->nullable();
            $table->integer('year')->nullable();
            $table->string('school')->nullable();
            $table->string('referred_by')->nullable();
            $table->string('archive_reason')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
