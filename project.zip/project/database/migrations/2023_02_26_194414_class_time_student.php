<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ClassTimeStudent extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('class_time_student', function (Blueprint $table) {
            $table->id();
            $table->foreignID('class_time_id')
                ->constrained("class_times")->cascadeOnUpdate()->cascadeOnDelete();
            $table->foreignID('student_id')
                ->constrained("students")->cascadeOnUpdate()->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('class_time_student');
    }
}
