<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendanceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendance', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('attendanceable_id')->index();
            $table->string('attendanceable_type');
            $table->foreignID('student_id')
                ->constrained("students")->cascadeOnUpdate()->cascadeOnDelete();
            $table->enum('status', ['PRESENT', 'PRESENT_FREE', 'ABSENT', 'ABSENT_EXCUSED'])->index()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendance');
    }
}
