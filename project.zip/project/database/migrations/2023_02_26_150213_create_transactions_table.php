<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id()->from(10000);
            $table->unsignedBigInteger('transactionable_id');
            $table->string('transactionable_type');
            $table->foreignID('subject_id')->nullable()->constrained("subjects")->cascadeOnUpdate();
            $table->enum('paid_by', ['CASH', 'C2C', 'POS', 'BANK_TRANSFER'])->index()->nullable();
            $table->enum('type', ['IN', 'OUT'])->index()->default('IN');
            $table->float('amount')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
