<?php

use App\Http\Controllers\AdvancePaymentController;
use App\Http\Controllers\BonusController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\ExtraController;
use App\Http\Controllers\FineController;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\LessonController;
use App\Http\Controllers\OfficeController;
use App\Http\Controllers\RecoveryController;
use App\Http\Controllers\RolesController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\SupportController;
use App\Http\Controllers\TagController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\TransactionController;

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

});

Route::middleware(['auth:web'])->group(function () {

    Route::resources([
        'teachers' => TeacherController::class,
        'students' => StudentController::class,
        'subjects' => SubjectController::class,
        'roles' => RolesController::class,
        'users' => UserController::class,
        'books' => BookController::class,
        'lessons' => LessonController::class,
        'staff' => StaffController::class
    ], ['index', 'store', 'update', 'destroy']);

    Route::post('/tags', [TagController::class, 'store']);
});

require __DIR__.'/auth.php';
