module.exports = {
    map: { inline: true },
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
};
