<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Attendance extends Model
{
    use HasFactory;

    protected $table = 'attendance';

    const STATUS_PRESENT = 'PRESENT';
    const STATUS_PRESENT_FREE = 'PRESENT_FREE';
    const STATUS_ABSENT = 'ABSENT';
    const STATUS_ABSENT_EXCUSED = 'ABSENT_EXCUSED';

    const STATUSES = [
        self::STATUS_PRESENT => [
            "color" => "success",
        ],
        self::STATUS_PRESENT_FREE => [
            "color" => "info",
        ],
        self::STATUS_ABSENT => [
            "color" => "error",
        ],
        self::STATUS_ABSENT_EXCUSED => [
            "color" => "warning",
        ],
    ];

    const TEACHER_STATUSES = [
        self::STATUS_PRESENT => [
            "color" => "success",
        ],
        self::STATUS_ABSENT => [
            "color" => "error",
        ],
    ];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    /**
     * Get the parent attendanceable model (lesson, support, recovery or extra).
     */
    public function attendanceable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get attendance record's student.
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    /**
     * Get attendance records's attendance.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'referencable');
    }
}
