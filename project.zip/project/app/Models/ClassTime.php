<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;
use Illuminate\Database\Eloquent\SoftDeletes;

class ClassTime extends Model
{
    use HasFactory, SoftDeletes;

    protected $casts = [
        'start_time' => 'datetime',
        'end_time' => 'datetime',
    ];

    const WEEKDAYS = [
        'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
    ];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];


    /**
     * Get classTime's group.
     */
    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class);
    }

    public function subject(): HasOneThrough
    {
        return $this->hasOneThrough(
        Subject::class,
        Group::class,
        'id', 'id', 'group_id', 'subject_id'
        );
    }

    /**
     * Get classTime's students.
     */
    public function students(): BelongsToMany
    {
        return $this->belongsToMany(Student::class);
    }

    /**
     * Get classTime's lessons.
     */
    public function lessons(): HasMany
    {
        return $this->hasMany(Lesson::class);
    }
}
