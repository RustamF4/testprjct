<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Lesson extends Model
{
    use HasFactory;

    protected $casts = [
        'start_time' => 'datetime',
        'end_time' => 'datetime',
    ];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];


    /**
     * Get lesson's classTime.
     */
    public function classTime(): BelongsTo
    {
        return $this->belongsTo(ClassTime::class)->withTrashed();
    }

    /**
     * Get lesson's teacher.
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }


    /**
     * Get lesson's students.
     */
    public function students(): BelongsToMany
    {
        return $this->morphToMany(Student::class, 'attendanceable', 'attendance')
            ->as('attendance')->withPivot('status');
    }

    /**
     * Get lessons's attendance.
     */
    public function attendance(): MorphMany
    {
        return $this->morphMany(Attendance::class, 'attendanceable');
    }
}
