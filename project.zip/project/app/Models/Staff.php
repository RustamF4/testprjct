<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Staff extends Model
{
    use HasFactory;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    /**
     * Get worker's transactions.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'transactionable');
    }

    /**
     * Get worker's advance payments.
     */
    public function advancePayments(): MorphMany
    {
        return $this->morphMany(AdvancePayment::class, 'applicable');
    }

    /**
     * Get worker's fines.
     */
    public function fines(): MorphMany
    {
        return $this->morphMany(Fine::class, 'applicable');
    }


    /**
     * Get worker's bonuses.
     */
    public function bonuses(): MorphMany
    {
        return $this->morphMany(Bonus::class, 'applicable');
    }
}
