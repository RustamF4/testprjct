<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Transaction extends Model
{
    use HasFactory;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    const PAID_BY_CASH = 'CASH';
    const PAID_BY_C2C = 'C2C';
    const PAID_BY_POS = 'POS';
    const PAID_BY_BANK_TRANSFER = 'BANK_TRANSFER';

    const TRANSACTION_TYPES = [
        self::PAID_BY_CASH => [
            "icon" => "dollar-sign",
            "color" => "success",
        ],
        self::PAID_BY_C2C => [
            "icon" => "credit-card",
            "color" => "secondary",
        ],
        self::PAID_BY_POS => [
            "icon" => "cash-register",
            "color" => "warning",
        ],
        self::PAID_BY_BANK_TRANSFER => [
            "icon" => "building-columns",
            "color" => "info",
        ],
    ];

    /**
     * Get the parent transactionable model (user, student, staff or teacher).
     */
    public function transactionable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get the color that is assigned to the transaction type.
     *
     * @param string $paid_by
     * @return string
     */
    public function getPaidByColor(string $paid_by): string
    {
        return self::TRANSACTION_TYPES[$paid_by]["color"];
    }

    /**
     * Get the icon that is assigned to the transaction type.
     *
     * @param string $paid_by
     * @return string
     */
    public function getPaidByIcon(string $paid_by): string
    {
        return self::TRANSACTION_TYPES[$paid_by]["icon"];
    }

    /**
     * Get the amount attribute with two decimal places.
     *
     * @return string
     */
    public function getFormattedAmountAttribute(): string
    {
        return number_format($this->attributes['amount'], 2);
    }

    /**
     * Get the subject that the transaction belongs to.
     */
    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class);
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class);
    }

    /**
     * Get the parent referencable model (attendance only as of now).
     */
    public function referencable(): MorphTo
    {
        return $this->morphTo();
    }
}
