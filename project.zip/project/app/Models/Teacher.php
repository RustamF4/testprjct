<?php

namespace App\Models;


use App\Helpers\AttendanceHelper;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Collection;
use Spatie\Permission\Traits\HasRoles;

class Teacher extends Authenticatable
{
    use HasFactory, SoftDeletes, HasRoles;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get teacher's thresholds.
     */
    public function thresholds(): HasMany
    {
        return $this->hasMany(Threshold::class)
            ->orderByRaw('CASE WHEN turnover IS NULL THEN 1 ELSE 0 END ASC, turnover ASC');
    }

    /**
     * Get teacher's groups.
     */
    public function groups(): HasMany
    {
        return $this->hasMany(Group::class);
    }

    /**
     * Get teacher's lessons.
     */
    public function lessons(): HasMany
    {
        return $this->hasMany(Lesson::class);
    }

    public function getThisWeekLessons(): Collection
    {
        // Lessons filtration must be set in the controller
        return AttendanceHelper::GenerateWeeklyTimetable($this->lessons);
    }

    /**
     * Get teacher's subjects.
     */
    public function subjects(): HasManyThrough
    {
        return $this->hasManyThrough(
            Subject::class,
            Group::class,
            'teacher_id', 'id', 'id', 'subject_id'
        )->distinct();
    }

    /**
     * Get teacher's advance payments.
     */
    public function advancePayments(): MorphMany
    {
        return $this->morphMany(AdvancePayment::class, 'applicable');
    }

    /**
     * Get teacher's fines.
     */
    public function fines(): MorphMany
    {
        return $this->morphMany(Fine::class, 'applicable');
    }


    /**
     * Get teacher's bonuses.
     */
    public function bonuses(): MorphMany
    {
        return $this->morphMany(Bonus::class, 'applicable');
    }

    /**
     * Get teacher's transactions.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'transactionable');
    }

    /**
     * Get office's by paid_by balance
     */
    public function getTurnoverAttribute(): float
    {
        $transactions = $this->transactions;

        $in = $transactions->where('type', 'IN')->sum('amount');
        $out = $transactions->where('type', 'OUT')->sum('amount');

        return $in - $out;
    }

    public function getFormattedTurnoverAttribute(): string
    {
        return number_format($this->getTurnoverAttribute(), 2) . ' ₼';
    }

    /**
     * Get turnover balance within the specified time range
     */
    public function calculateTurnover(Carbon $startDate, Carbon $endDate): float
    {

        $transactions = $this->transactions()->whereHas('referencable',
            function ($query) use ($startDate, $endDate) {
                $query
                    ->where('referencable_type', 'App\Models\Attendance')
                    ->whereHasMorph(
                        'attendanceable',
                        ['App\Models\Lesson', 'App\Models\Extra', 'App\Models\Support', 'App\Models\Recovery'],
                        function ($subQuery) use ($startDate, $endDate) {
                            $subQuery->whereBetween('start_time', [$startDate, $endDate]);
                        });
            }
        )->get();

        $in = $transactions->where('type', 'IN')->sum('amount');
        $out = $transactions->where('type', 'OUT')->sum('amount');

        return $in - $out;
    }
}
