<?php

namespace App\Models;

use App\Helpers\AttendanceHelper;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Collection;

class Student extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];


    /**
     * Get student's emergency contacts.
     */
    public function contacts(): HasMany
    {
        return $this->hasMany(StudentContact::class);
    }

    /**
     * Get student's books.
     */
    public function books(): BelongsToMany
    {
        return $this->belongsToMany(Book::class)->withPivot('amount_left');
    }

    /**
     * Get student's groups.
     */
    public function groups(): BelongsToMany
    {
        return $this->belongsToMany(Group::class)->withPivot('price');
    }

    /**
     * Get student's subjects.
     */
    public function subjects()
    {
        return Subject::select('subjects.*')
            ->join('groups', 'subjects.id', '=', 'groups.subject_id')
            ->join('group_student', 'groups.id', '=', 'group_student.group_id')
            ->join('students', 'students.id', '=', 'group_student.student_id')
            ->where('students.id', $this->id)
            ->distinct();
    }

    /**
     * Get student's classTimes.
     */
    public function classTimes(): BelongsToMany
    {
        return $this->belongsToMany(ClassTime::class)->orderBy('weekday');
    }

    /**
     * Get student's lessons.
     */
    public function lessons(): BelongsToMany
    {
        return $this->morphedByMany(Lesson::class, 'attendanceable', 'attendance')
            ->as('attendance')
            ->withPivot('status');
    }

    public function getThisWeekLessons(): Collection
    {
        // Lessons filtration must be set in the controller
        return AttendanceHelper::GenerateWeeklyTimetable($this->lessons);
    }

    /**
     * Get student's transactions.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'transactionable');
    }

    /**
     * Get student's subject balance
     */
    public function getSubjectBalance(int $subject_id): string
    {
        return $this->getSubjectBalanceValue($subject_id) . ' ₼';
    }

    /**
     * Get student's subject balance
     */
    public function getSubjectBalanceValue(int $subject_id): float
    {
        $transactions = $this->transactions->where('subject_id', $subject_id);

        $in = $transactions->where('type', 'IN')->sum('amount');
        $out = $transactions->where('type', 'OUT')->sum('amount');

        return $in - $out;
    }
}
