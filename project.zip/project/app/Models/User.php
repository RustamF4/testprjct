<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    const OFFICE_ID = 1;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Get office's transactions.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'transactionable');
    }

    /**
     * Get office's by paid_by balance
     */
    public function getPaidByIncomeInTimeSpan(string $paid_by, Carbon $startDate, Carbon $endDate): float
    {
        return $this
                ->transactions
                ->whereBetween('created_at', [$startDate, $endDate])
                ->where('paid_by', $paid_by)
                ->where('type', 'IN')
                ->sum('amount');
    }

    /**
     * Get office's by paid_by balance
     */
    public function getPaidByExpenseInTimeSpan(string $paid_by, Carbon $startDate, Carbon $endDate): float
    {
        return $this
            ->transactions
            ->whereBetween('created_at', [$startDate, $endDate])
            ->where('paid_by', $paid_by)
            ->where('type', 'OUT')
            ->sum('amount');
    }

    /**
     * Get office's by paid_by balance
     */
    public function getPaidByBalance(string $paid_by): string
    {
        $transactions = $this->transactions;

        $in = $transactions->where('paid_by', $paid_by)->where('type', 'IN')->sum('amount');
        $out = $transactions->where('paid_by', $paid_by)->where('type', 'OUT')->sum('amount');

        return number_format($in - $out, '2');
    }

    /**
     * Get office's by paid_by balance info
     */
    public function getPaidByChangeInTimeSpan(string $paid_by, Carbon $startDate, Carbon $endDate): string
    {
        $transactions = $this->transactions;

        $in = $transactions->where('paid_by', $paid_by)->where('type', 'IN')->sum('amount');
        $out = $transactions->where('paid_by', $paid_by)->where('type', 'OUT')->sum('amount');

        $new_balance = $in - $out;

        $in_old = $transactions->where('paid_by', $paid_by)->where('type', 'IN')
            ->whereBetween('created_at', [$startDate, $endDate])->sum('amount');
        $out_old = $transactions->where('paid_by', $paid_by)->where('type', 'OUT')
            ->whereBetween('created_at', [$startDate, $endDate])->sum('amount');

        $old_balance = $in_old - $out_old;

        if ($old_balance == $new_balance)
            return "0.00";

        if ($old_balance == 0)
            return $new_balance > 0 ? "100.00" : "-100.00";

        return number_format(
            (($new_balance - $old_balance) / abs($old_balance) * 100),
            '2'
        );
    }
}
