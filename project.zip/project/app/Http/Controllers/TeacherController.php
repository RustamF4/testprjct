<?php

namespace App\Http\Controllers;

use App\Helpers\DateHelper;
use App\Helpers\RequestHelper;
use App\Http\Requests\CreateTeacherRequest;
use App\Http\Requests\CreateThresholdRequest;
use App\Http\Requests\DeleteTeacherRequest;
use App\Http\Requests\UpdateTeacherRequest;
use App\Http\Requests\UpdateThresholdRequest;
use App\Models\AdvancePayment;
use App\Models\AdvancePaymentRecord;
use App\Models\Bonus;
use App\Models\Extra;
use App\Models\Fine;
use App\Models\Lesson;
use App\Models\Recovery;
use App\Models\Support;
use App\Models\Teacher;

use App\Models\Threshold;
use App\Models\Transaction;
use App\Models\User;
use App\Rules\StringIsValidDate;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use Fuse\Fuse;


class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view teachers'))
        {
            return view('pages.office.blank');
        }

        $query = $request->input('search');
        $teachers = Teacher::with([
            'thresholds',
            'transactions',
            'groups' => function ($query) {
                $query->with('subject')->withCount('students');
            },
            'lessons' => function ($query) {
                $query->whereBetween('start_time', DateHelper::getThisWeekBoundaries())->with([
                    'classtime' => function ($query) {
                        $query->with('group')->orderBy('weekday', 'asc')->orderBy('start_time', 'asc');
                    },
                    'students',
                ]);
            },
        ]);
        $teachers = self::searchTeachers($query, $teachers);

        return view('pages.office.teachers')->with([
            'teachers' => $teachers,
            'query' => $query,
            'now' => Carbon::now()
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function deletedIndex(Request $request)
    {
        $query = $request->input('search');

        $teachers = Teacher::onlyTrashed()->with('groups');

        $teachers = self::searchTeachers($query, $teachers);

        return view('pages.office.deleted.teachers')->with([
            'teachers' => $teachers,
            'query' => $query,
            'now' => Carbon::now()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  CreateTeacherRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateTeacherRequest $request)
    {
        $teacher = new Teacher;
        $teacher->name = $request->input('name');
        $teacher->surname = $request->input('surname');
        $teacher->email = $request->input('email');
        $teacher->phone = $request->input('phone');
        $teacher->salary = $request->input('salary') ?? 0;
        $teacher->actual_salary = $request->input('actual_salary') ?? 0;
        $teacher->salary_per_lesson = $request->input('salary_per_lesson') ?? 0;
        $teacher->referred_by = $request->input('referred_by');
        $teacher->password = Hash::make($request->input('password'));

        $teacher->save();

        $teacher->assignRole('teacher');

        return redirect()->back()
            ->with('success', 'Teacher created successfully');
    }

    /**
     * Store a newly created student contact in storage.
     *
     * @param  CreateThresholdRequest  $request
     * @param  Teacher  $teacher
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeThreshold(CreateThresholdRequest $request, Teacher $teacher)
    {
        $hasNoLimit = $request->filled('has_no_limit');
        $isFixed = $request->filled('is_fixed');

        $threshold = new Threshold([
            'turnover' => $hasNoLimit ? null : $request->turnover,
            'amount' => $isFixed ? $request->amount : null,
            'percent' => $isFixed ? null : $request->percent,
            'is_fixed' => $isFixed,
        ]);

        $teacher->thresholds()->save($threshold);

        return redirect()->back()
            ->with('updated_teacher_id_threshold', $teacher->id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateTeacherRequest $request
     * @param  Teacher $teacher
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateTeacherRequest $request, Teacher $teacher)
    {
        $teacher->name = $request->input('name');
        $teacher->surname = $request->input('surname');
        $teacher->email = $request->input('email');
        $teacher->phone = $request->input('phone');
        $teacher->salary = $request->input('salary') ?? $teacher->salary;
        $teacher->actual_salary = $request->input('actual_salary') ?? $teacher->actual_salary;
        $teacher->salary_per_lesson = $request->input('salary_per_lesson') ?? $teacher->salary_per_lesson;

        if ($request->filled('password')) {
            $teacher->password = Hash::make($request->input('password'));
        }

        $teacher->touch();

        return redirect()->back()
            ->with('success', 'Teacher updated successfully');
    }

    /**
     * Update the student contact in storage.
     *
     * @param  UpdateThresholdRequest  $request
     * @param  Threshold  $threshold
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateThreshold(UpdateThresholdRequest $request, Threshold $threshold)
    {
        $hasNoLimit = $request->filled('has_no_limit');
        $isFixed = $request->filled('is_fixed');

        $threshold->turnover = $hasNoLimit ? null : $request->turnover;
        $threshold->amount = $isFixed ? $request->amount : null;
        $threshold->percent = $isFixed ? null : $request->percent;
        $threshold->is_fixed = $request->filled('is_fixed');

        $threshold->save();

        return redirect()->back()
            ->with('updated_teacher_id_threshold', $threshold->teacher->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteTeacherRequest $request
     * @param  Teacher $teacher
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(DeleteTeacherRequest $request, Teacher $teacher)
    {
        $teacher->archive_reason = $request->input('archive_reason');
        $teacher->touch();
        $teacher->delete();

        return redirect()->back()
            ->with('success', 'Teacher deleted successfully');
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param int $teacher_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore(int $teacher_id)
    {
        $teacher = Teacher::onlyTrashed()->where('id', $teacher_id)->firstOrFail();
        $teacher->restore();
        $teacher->archive_reason = null;
        $teacher->touch();

        return redirect()->back()
            ->with('success', 'Teacher restored successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Threshold $threshold
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroyThreshold(Threshold $threshold)
    {
        $teacherId = $threshold->teacher->id;
        $threshold->delete();

        return redirect()->back()
            ->with('updated_teacher_id_threshold', $teacherId);
    }


    public function calculateSalary(Request $request, Teacher $teacher)
    {
        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
        ]);

        $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);

        $startDate = $dateRange[0];
        $endDate = $dateRange[1];

        $advance_payment = null;
        $bonuses = [];
        $fines = [];
        $types = Transaction::TRANSACTION_TYPES;

        $turnover = $teacher->calculateTurnover($startDate, $endDate);
        $salaryBreakdown = [];
        $totalAmountBasedOnTurnover = 0;
        $runningAmount = 0;

        foreach ($teacher->thresholds as $threshold)
        {
            if ($runningAmount >= $turnover)
                break;

            $amountLeft = $turnover - $runningAmount;
            $turnoverToOperate = $threshold->turnover
                ? min($amountLeft, $threshold->turnover - $runningAmount)
                : $amountLeft;
            $amount = $threshold->is_fixed
                ? $threshold->amount
                : ($threshold->percent / 100) * $turnoverToOperate;
            $runningAmount += $turnoverToOperate;

            $salaryBreakdown[] = [
                'threshold' => $threshold,
                'calculated_amount' => $amount,
                'affected_amount' => $turnoverToOperate ?? 0
            ];

            $totalAmountBasedOnTurnover += $amount;
        }

        if ($request->advance == 'on') {
            $advance_payment = $teacher
                ->advancePayments()
                ->where('remaining_amount', '>', 0)
                ->first();
        }

        if ($request->bonus == 'on') {
            $bonuses = $teacher
                ->bonuses()
                ->where('is_paid', false)
                ->get();
        }

        if ($request->fine == 'on') {
            $fines = $teacher
                ->fines()
                ->where('is_paid', false)
                ->get();
        }

        $lessons = Lesson::whereBetween('start_time', [$startDate, $endDate])
            ->whereTeacherId($teacher->id)
            ->whereHas('attendance', function ($query) {
                $query->whereNotNull('status');
            })->count();
        $extra = Extra::whereBetween('start_time', [$startDate, $endDate])
            ->whereTeacherId($teacher->id)
            ->whereHas('attendance', function ($query) {
                $query->whereNotNull('status');
            })->count();
        $recovery = Recovery::whereBetween('start_time', [$startDate, $endDate])
            ->whereTeacherId($teacher->id)
            ->whereHas('attendance', function ($query) {
                $query->whereNotNull('status');
            })->whereTeacherGetsPaid(1)->count();

        $lessons_data = [
            'Scheduled Lessons' => $lessons,
            'Extra Lessons' => $extra,
            'Paid Recovery Lessons' => $recovery
        ];

        $data = [
            'salaryBreakdown' => $salaryBreakdown,
            'advancePayment' => $advance_payment,
            'bonuses' => $bonuses,
            'fines' => $fines,
            'lessonsData' => $lessons_data
        ];

        return view('pages.office.teacher-salary')->with([
            'data' => $data,
            'teacher' => $teacher,
            'turnover' => $turnover,
            'initial' => $totalAmountBasedOnTurnover,
            'total_lessons' => $lessons + $extra + $recovery,
            'lesson_based_calculation' => $request->lesson_based == 'on',
            'paid_byes' => $types
        ]);
    }

    public function generateReport(Request $request, Teacher $teacher) {

        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
        ]);

        $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);

        $startDate = $dateRange[0];
        $endDate = $dateRange[1];

        // Generate Lesson Data
        $lessons_data = [
            'Scheduled Lessons' => Lesson::whereBetween('start_time', [$startDate, $endDate])
                ->whereTeacherId($teacher->id)
                ->whereHas('attendance', function ($query) {
                    $query->whereNotNull('status');
                })->count(),
            'Support Lessons' => Support::whereBetween('start_time', [$startDate, $endDate])
                ->whereTeacherId($teacher->id)
                ->whereHas('attendance', function ($query) {
                    $query->whereNotNull('status');
                })->count(),
            'Extra Lessons' => Extra::whereBetween('start_time', [$startDate, $endDate])
                ->whereTeacherId($teacher->id)
                ->whereHas('attendance', function ($query) {
                    $query->whereNotNull('status');
                })->count(),
            'Recovery Lessons' => Recovery::whereBetween('start_time', [$startDate, $endDate])
                ->whereTeacherId($teacher->id)
                ->whereHas('attendance', function ($query) {
                    $query->whereNotNull('status');
                })->count()
        ];

        // Generate Subjects Data
        $subjects_data = $teacher->subjects
            ->map(function($subject) use ($teacher, $startDate, $endDate) {
            return [
                'subject' => $subject->name,
                'total_students' =>
                    $subject->groups()
                        ->where(function ($query) use ($startDate, $endDate) {
                            $query->where('starts_at', '<=', $startDate)
                                ->orWhere('ends_at', '>=', $endDate->subDay()
                            );
                        })
                        ->withCount('students')->get()
                        ->sum('students_count')
            ];
        });

        // Generate Group Data
        $groups_data = $teacher->groups()
            ->where(function ($query) use ($startDate, $endDate) {
                $query->where('starts_at', '<=', $startDate)
                    ->orWhere('ends_at', '>=', $endDate->subDay()
                    );
            })
            ->withCount('students')->get()
            ->map(function($group) {
                return [
                    'group' => $group->name,
                    'total_students' => $group->students_count
                ];
            });

        // Generate Salary Data
        $months = [];

        while ($startDate->lessThanOrEqualTo($endDate)) {

            $months[$startDate->format('M, Y')] = [
                "to_card" => Transaction::whereType('OUT')
                    ->whereTransactionableId(User::OFFICE_ID)
                    ->whereTransactionableType(User::class)
                    ->whereBetween('created_at', [$startDate, $startDate->copy()->endOfMonth()->addDay()])
                    ->where('note', '=',
                        'Paid for ' . $teacher->name . ' ' . $teacher->surname . ' official salary'
                    )->first(),
                "calculated_salary" => Transaction::whereType('OUT')
                    ->whereTransactionableId(User::OFFICE_ID)
                    ->whereTransactionableType(User::class)
                    ->whereBetween('created_at', [$startDate, $startDate->copy()->endOfMonth()->addDay()])
                    ->where('note', '=',
                        'Paid for ' . $teacher->name . ' ' . $teacher->surname . ' salary'
                    )->first(),
                "fines" => $teacher->fines()
                    ->whereBetween('created_at', [$startDate, $startDate->copy()->endOfMonth()->addDay()])->get(),
                "bonuses" => $teacher->bonuses()
                    ->whereBetween('created_at', [$startDate, $startDate->copy()->endOfMonth()->addDay()])->get(),
            ];

            $startDate->addMonth();
        }


        $data = [
            'lessons_data' => $lessons_data,
            'subjects_data' => $subjects_data,
            'groups_data' => $groups_data,
            'months' => $months
        ];

        return view('pages.office.teacher-report')->with([
            'data' => $data,
            'teacher' => $teacher
        ]);
    }

    public function paySalary(Request $request, Teacher $teacher) {

        $request->validate([
            'amount' => 'required|numeric|min:0',
            'turnover' => 'required|numeric|min:0',
            'advance_payment_id' => 'nullable|exists:advance_payments,id',
            'advance_payment_amount' => 'nullable|min:0',
            'bonusIds' => 'nullable|array',
            'bonusIds.*' => 'exists:bonuses,id',
            'fineIds' => 'nullable|array',
            'fineIds.*' => 'exists:fines,id',
            'paid_by' => 'required|in:CASH,C2C,POS,BANK_TRANSFER',
            'type' => 'required|in:OUT,IN',
        ]);

        DB::beginTransaction();

        try
        {
            Transaction::create([
                'transactionable_id' => $teacher->id,
                'transactionable_type' => Teacher::class,
                'amount' => $request->turnover,
                'type' => 'OUT',
                'note' => 'Deducted on salary payment',
            ]);

            Transaction::create([
                'transactionable_id' => User::OFFICE_ID,
                'transactionable_type' => User::class,
                'amount' => $request->amount,
                'type' => $request->type,
                'paid_by' => $request->paid_by,
                'note' => 'Paid for ' . $teacher->name . ' ' . $teacher->surname . ' salary',
            ]);

            Transaction::create([
                'transactionable_id' => User::OFFICE_ID,
                'transactionable_type' => User::class,
                'amount' => $teacher->actual_salary,
                'type' => 'OUT',
                'paid_by' => Transaction::PAID_BY_BANK_TRANSFER,
                'note' => 'Paid for ' . $teacher->name . ' ' . $teacher->surname . ' official salary',
            ]);

            if ($request->has('advance_payment_id')) {
                $payment = AdvancePayment::findOrFail($request->advance_payment_id);
                $record = new AdvancePaymentRecord([
                    'amount' => $request->advance_payment_amount,
                    'note' => 'Payment was deducted while forming the salary'
                ]);

                $payment->records()->save($record);
                $payment->remaining_amount = $payment->remaining_amount - $record->amount;
                $payment->touch();
            }

            if ($request->has('bonusIds')) {
                foreach ($request->bonusIds as $bonus_id) {
                    $bonus = Bonus::findOrFail($bonus_id);
                    $bonus->is_paid = 1;
                    $bonus->touch();
                }
            }

            if ($request->has('fineIds')) {
                foreach ($request->fineIds as $fine_id) {
                    $fine = Fine::findOrFail($fine_id);
                    $fine->is_paid = 1;
                    $fine->touch();
                }
            }

            DB::commit();

            return redirect('/teachers');
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back();
        }
    }

    private static function searchTeachers($query, $teachers) {
        if (!empty($query)) {
            $fuse = new Fuse($teachers->get()->toArray(), [
                'keys' => ['name', 'surname', 'phone', 'email'],
                'threshold' => 0.3,
            ]);

            $results = $fuse->search($query);

            $teacherIds = array_filter(array_map(function ($result) {
                return $result['item']['id'] ?? null;
            }, $results));

            $teachers = Teacher::whereIn('id', $teacherIds);
        }

        return $teachers
            ->paginate(10)
            ->withQueryString();
    }
}
