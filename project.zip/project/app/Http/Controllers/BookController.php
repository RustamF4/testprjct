<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateBookRequest;
use App\Http\Requests\DeleteBookRequest;
use App\Http\Requests\PayForTheBookRequest;
use App\Http\Requests\SellBookToStudentRequest;
use App\Http\Requests\UpdateBookRequest;
use App\Models\Book;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Transaction;
use Auth;
use Fuse\Fuse;
use Illuminate\Http\Request;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view books'))
        {
            return view('pages.office.blank');
        }

        $query = $request->input('search');

        $books = Book::with([
            'students' => function ($query) {
                $query->withPivot('amount_left');
            },
            'students.transactions',
            'subject'
        ]);

        if (!empty($query)) {
            $fuse = new Fuse($books->get()->toArray(), [
                'keys' => ['name', 'price'],
                'threshold' => 0.3,
            ]);

            $results = $fuse->search($query);

            $bookIds = array_filter(array_map(function ($result) {
                return $result['item']['id'] ?? null;
            }, $results));

            $books = Book::whereIn('id', $bookIds);
        }

        $books = $books
            ->paginate(10)
            ->withQueryString();
        $paid_byes = Transaction::TRANSACTION_TYPES;
        $subjects = Subject::all();

        return view('pages.office.books')->with([
            'subjects' => $subjects,
            'books' => $books,
            'query' => $query,
            'paid_byes' => $paid_byes
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  CreateBookRequest $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateBookRequest $request)
    {
        Book::create([
            'subject_id' => $request->subject_id,
            'name' => $request->name,
            'price' => $request->price,
        ]);

        return redirect()->back()
            ->with('success', 'Student created successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateBookRequest $request
     * @param  Book $book
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateBookRequest $request, Book $book)
    {
        $book->name = $request->name;
        $book->price = $request->price;
        $book->subject_id = $request->subject_id;

        $book->touch();

        return redirect()->back()
            ->with('success', 'Student updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteBookRequest $request
     * @param  Book $book
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(DeleteBookRequest $request, Book $book)
    {
        $book->archive_reason = $request->archive_reason;
        $book->touch();
        $book->delete();

        return redirect()->back()
            ->with('success', 'Student deleted successfully');
    }


    public function sellToStudent(SellBookToStudentRequest $request, Book $book)
    {
        $studentId = $request->student_id;

        $book->students()->attach($studentId, ['amount_left' => $book->price - $request->amount_paid]);

        Transaction::create([
            'transactionable_id' => $studentId,
            'transactionable_type' => Student::class,
            'subject_id' => $book->subject->id,
            'amount' => $request->amount_paid,
            'type' => 'OUT',
            'note' => 'Deducted For the Book Payment. BookID: ' . $book->id,
        ]);

        return redirect()->back()
            ->with('updated_book_id_student', $book->id);
    }

    public function payForBook(PayForTheBookRequest $request, Book $book)
    {
        $studentId = $request->student_id;

        $amountLeft = $book
            ->students()
            ->where('student_id', $studentId)
            ->first()->pivot->amount_left;

        $book->students()->updateExistingPivot($studentId, ['amount_left' => $amountLeft - $request->amount]);

        Transaction::create([
            'transactionable_id' => $studentId,
            'transactionable_type' => Student::class,
            'subject_id' => $book->subject->id,
            'amount' => $request->amount,
            'type' => 'OUT',
            'note' => 'Deducted For the Book Payment. BookID: ' . $book->id,
        ]);

        return redirect()->back()
            ->with('updated_book_id_student', $book->id);
    }

    public function changeAmountLeftForStudent(PayForTheBookRequest $request, Book $book)
    {
        $studentId = $request->student_id;

        $book->students()->updateExistingPivot($studentId, ['amount_left' => $request->amount]);

        return redirect()->back()
            ->with('updated_book_id_student', $book->id);
    }
}
