<?php

namespace App\Http\Controllers;

use App\Helpers\AttendanceHelper;
use App\Helpers\DateHelper;
use App\Helpers\RequestHelper;
use App\Http\Requests\CreateStudentContactRequest;
use App\Http\Requests\CreateStudentRequest;
use App\Http\Requests\DeleteStudentContactRequest;
use App\Http\Requests\DeleteStudentFromGroup;
use App\Http\Requests\DeleteStudentRequest;
use App\Http\Requests\UpdateStudentGroupInfoRequest;
use App\Http\Requests\UpdateStudentContactRequest;
use App\Http\Requests\UpdateStudentRequest;
use App\Models\AdvancePayment;
use App\Models\Attendance;
use App\Models\ClassTime;
use App\Models\Extra;
use App\Models\Group;
use App\Models\Lesson;
use App\Models\Recovery;
use App\Models\Student;

use App\Models\StudentContact;
use App\Models\Support;
use App\Models\Transaction;
use App\Rules\StringIsValidDate;
use Carbon\Carbon;
use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

use Fuse\Fuse;
use Illuminate\Support\Facades\Auth;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view students'))
        {
            return view('pages.office.blank');
        }

        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
            'name' => [
                'nullable',
                'string'
            ],
            'surname' => [
                'nullable',
                'string'
            ],
            'school' => [
                'nullable',
                'string'
            ],
            'year' => [
                'nullable',
                'string'
            ],
            'parents' => [
                'nullable',
                'string'
            ],
        ]);

        $students = Student::query();
        $students = $this->searchStudents($students, $request);

        $students = $students
            ->with([
                'groups',
                'contacts',
                'transactions',
                'lessons' => function ($query) {
                    $query->whereBetween('start_time', DateHelper::getThisWeekBoundaries())->with([
                        'classtime' => function ($query) {
                            $query->orderBy('weekday', 'asc')->orderBy('start_time', 'asc');
                        },
                        'classtime.group',
                        'teacher',
                    ]);
                },
                'classTimes' => function ($query) {
                    $query->orderBy('weekday', 'asc')->orderBy('start_time', 'asc');
                },
                'groups' => function ($query) {
                    $query->withPivot('price');
                },
                'groups.teacher',
                'groups.subject.classTimes' => function ($query) {
                    $query->orderBy('weekday', 'asc')->orderBy('start_time', 'asc');
                },
                'groups.subject.classTimes.group.teacher'
            ])
            ->orderBy('year')
            ->orderBy('id')
            ->paginate(10)
            ->withQueryString();

        $paid_byes = Transaction::TRANSACTION_TYPES;

        return view('pages.office.students')->with([
            'students' => $students,
            'paid_byes' => $paid_byes,
            'now' => Carbon::now()
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function deletedIndex(Request $request)
    {
        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
            'search' => [
                'nullable',
                'string'
            ],
        ]);

        $students = Student::onlyTrashed();
        $students = $this->searchStudents($students, $request);

        $students = $students
            ->paginate(10)
            ->withQueryString();

        return view('pages.office.deleted.students')->with([
            'students' => $students
        ]);
    }

    /**
     * Generate report on the students' balance
     *
     */
    public function generateDebtReport(Request $request)
    {
        $students = Student::with('transactions')->get();
        $balances = [];

        foreach ($students as $student) {
            $subjectBalances = [];
            $maxDebt = 0;

            foreach ($student->subjects()->get() as $subject) {
                $balance = $student->getSubjectBalanceValue($subject->id);

                if ($balance < $maxDebt) {
                    $maxDebt = $balance;
                }

                $subjectBalances[] = ['subject' => $subject->name, 'balance' => $balance];
            }

            if ($request->debtors_only == 'on' && $maxDebt >= 0) {
                continue;
            }

            $balances[] = [
                'student' => $student->name . ' ' . $student->surname,
                'maxDebt' => $maxDebt,
                'subjects' => $subjectBalances
            ];
        }

        usort($balances, function ($a, $b) {
            return $a['maxDebt'] - $b['maxDebt'];
        });

        return view('pages.office.students-report')->with([
            'data' => $balances
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  CreateStudentRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateStudentRequest $request)
    {
        Student::create([
            'name' => $request->name,
            'surname' => $request->surname,
            'middle_name' => $request->middle_name,
            'category' => $request->category,
            'phone' => $request->phone,
            'info' => $request->info,
            'year' => $request->year,
            'school' => $request->school,
            'referred_by' => $request->referred_by,
        ]);

        return redirect()->back()
            ->with('success', 'Student created successfully');
    }

    /**
     * Store a newly created student contact in storage.
     *
     * @param  CreateStudentContactRequest  $request
     * @param  Student  $student
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeContact(CreateStudentContactRequest $request, Student $student)
    {
        $contact = new StudentContact([
            'title' => $request->title,
            'name' => $request->name,
            'surname' => $request->surname,
            'phone' => $request->phone,
        ]);

        $student->contacts()->save($contact);

        return redirect()->back()
            ->with('updated_student_id_contact', $student->id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateStudentRequest $request
     * @param  Student $student
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateStudentRequest $request, Student $student)
    {
        $student->name = $request->name;
        $student->surname = $request->surname;
        $student->middle_name = $request->middle_name;
        $student->category = $request->category;
        $student->phone = $request->phone;
        $student->info = $request->info;
        $student->year = $request->year;
        $student->school = $request->school;
        $student->referred_by = $request->referred_by;

        $student->touch();

        return redirect()->back()
            ->with('success', 'Student updated successfully');
    }

    /**
     * Update the student contact in storage.
     *
     * @param  UpdateStudentContactRequest  $request
     * @param  StudentContact  $studentContact
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateContact(UpdateStudentContactRequest $request, StudentContact $studentContact)
    {
        $studentContact->title = $request->title;
        $studentContact->name = $request->name;
        $studentContact->surname = $request->surname;
        $studentContact->phone = $request->phone;

        $studentContact->touch();

        return redirect()->back()
            ->with('updated_student_id_contact', $studentContact->student->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteStudentRequest $request
     * @param  Student $student
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(DeleteStudentRequest $request, Student $student)
    {
        DB::beginTransaction();
        try
        {
            $student->archive_reason = $request->archive_reason;
            $student->touch();

            foreach ($student->groups as $group) {
                foreach ($student->classTimes()->whereHas('group', function ($query) use ($group) {
                    $query->whereHas('subject', function ($query) use ($group) {
                        $query->where('subjects.id', $group->subject_id);
                    });
                })->get() as $class_time) {
                    AttendanceHelper::DeleteStudentsFutureAttendanceForClassTime(
                        $class_time, $student->id
                    );
                }

                $student->classTimes()->whereHas('group', function ($query) use ($group) {
                    $query->whereHas('subject', function ($query) use ($group) {
                        $query->where('subjects.id', $group->subject_id);
                    });
                })->detach();
                $group->students()->detach($student->id);
            }

            $student->delete();
            DB::commit();

            return redirect()->back()
                ->with('success', 'Student deleted successfully');
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back()
                ->with('error', $e->getMessage());
        }
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param int $student_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore(int $student_id)
    {
        $student = Student::onlyTrashed()->where('id', $student_id)->firstOrFail();
        $student->restore();
        $student->archive_reason = null;
        $student->touch();

        return redirect()->back()
            ->with('success', 'Teacher restored successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteStudentContactRequest $request
     * @param  StudentContact $studentContact
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroyContact(DeleteStudentContactRequest $request, StudentContact $studentContact)
    {
        $studentContact->archive_reason = $request->input('archive_reason');
        $studentContact->touch();
        $studentContact->delete();

        return redirect()->back()
            ->with('updated_student_id_contact', $studentContact->student->id);
    }

    private function searchStudents($students, Request $request)
    {
        if (isset($request->date_range))
        {
            $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);
            $students = $students->whereBetween('created_at', [$dateRange[0], $dateRange[1]]);
        }

        if (isset($request->name))
        {
            $students = $students->where('name', 'like', $request->name . '%');
        }

        if (isset($request->surname))
        {
            $students = $students->where('surname', 'like', $request->surname . '%');
        }

        if (isset($request->school))
        {
            $students = $students->where('school', 'like', '%' . $request->school . '%');
        }

        if (isset($request->year))
        {
            $students = $students->where('year', $request->year);
        }

        if (isset($request->parents))
        {
            $studentIds = $students->pluck('id')->toArray();
            $query = $request->parents;

            $contactStudentIds = StudentContact::whereIn('student_id', $studentIds)
                ->where(function ($search) use ($query) {
                    $search->where('name', 'like', $query . '%')
                        ->orWhere('surname', 'like', $query . '%');
                })->pluck('student_id')->toArray();

            $students = Student::whereIn('id', $contactStudentIds);
        }

        return $students;
    }
}
