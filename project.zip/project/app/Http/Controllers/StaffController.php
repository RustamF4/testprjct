<?php

namespace App\Http\Controllers;

use App\Helpers\RequestHelper;
use App\Http\Requests\CreateStaffRequest;
use App\Http\Requests\DeleteStaffRequest;
use App\Http\Requests\UpdateStaffRequest;
use App\Models\AdvancePayment;
use App\Models\AdvancePaymentRecord;
use App\Models\Bonus;
use App\Models\Fine;
use App\Models\Staff;
use App\Models\Teacher;
use App\Models\Transaction;
use App\Models\User;
use App\Rules\StringIsValidDate;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index()
    {
        $user = Auth::user();

        if ($user->cannot('view staff'))
        {
            return view('pages.office.blank');
        }

        $paid_byes = Transaction::TRANSACTION_TYPES;

        $staff = Staff::query()
            ->with('transactions')
            ->paginate(10);

        return view('pages.office.staff')->with([
            'staff' => $staff,
            'paid_byes' => $paid_byes,
            'now' => Carbon::now()
        ]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @param  CreateStaffRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateStaffRequest $request)
    {
        Staff::create([
            'name' => $request->name,
            'surname' => $request->surname,
            'salary' => $request->salary,
            'salary_card' => $request->salary_card,
            'email' => $request->email,
            'phone' => $request->phone,
        ]);

        return redirect()->back()
            ->with('success', 'Staff member created successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateStaffRequest $request
     * @param  Staff $staff
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateStaffRequest $request, Staff $staff)
    {
        $staff->name = $request->input('name') ?? $staff->name;
        $staff->surname = $request->input('surname') ?? $staff->surname;
        $staff->email = $request->input('email') ?? $staff->email;
        $staff->phone = $request->input('phone') ?? $staff->phone;
        $staff->salary = $request->input('salary') ?? $staff->salary;
        $staff->salary_card = $request->input('salary_card') ?? $staff->salary_card;

        $staff->touch();

        return redirect()->back()
            ->with('success', 'Stuff updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteStaffRequest $request
     * @param  Staff $staff
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(DeleteStaffRequest $request, Staff $staff)
    {
        $staff->archive_reason = $request->input('archive_reason');
        $staff->touch();
        $staff->delete();

        return redirect()->back()
            ->with('success', 'Staff deleted successfully');
    }

    public function calculateSalary(Request $request, Staff $staff)
    {
        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
        ]);

        $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);

        $startDate = $dateRange[0];
        $endDate = $dateRange[1];

        $advance_payment = null;
        $bonuses = [];
        $fines = [];
        $types = Transaction::TRANSACTION_TYPES;

        if ($request->advance == 'on') {
            $advance_payment = $staff
                ->advancePayments()
                ->where('remaining_amount', '>', 0)
                ->first();
        }

        if ($request->bonus == 'on') {
            $bonuses = $staff
                ->bonuses()
                ->where('is_paid', false)
                ->get();
        }

        if ($request->fine == 'on') {
            $fines = $staff
                ->fines()
                ->where('is_paid', false)
                ->get();
        }

        $data = [
            'advancePayment' => $advance_payment,
            'bonuses' => $bonuses,
            'fines' => $fines
        ];

        return view('pages.office.staff-salary')->with([
            'data' => $data,
            'worker' => $staff,
            'initial' => $staff->salary,
            'paid_byes' => $types
        ]);
    }

    public function paySalary(Request $request, Staff $staff)
    {
        $user = Auth::user();

        if ($user->cannot('pay staff member')) {
            return redirect()->back();
        }

        $request->validate([
            'amount' => 'required|numeric',
            'advance_payment_id' => 'nullable|exists:advance_payments,id',
            'advance_payment_amount' => 'nullable|min:0',
            'bonusIds' => 'nullable|array',
            'bonusIds.*' => 'exists:bonuses,id',
            'fineIds' => 'nullable|array',
            'fineIds.*' => 'exists:fines,id',
            'paid_by' => 'required|in:CASH,C2C,POS,BANK_TRANSFER',
            'type' => 'required|in:OUT,IN',
        ]);

        DB::beginTransaction();

        try
        {
            $amount = 0;

            if ($request->amount > 0) {
                $amount = $request->amount;
                Transaction::create([
                    'transactionable_id' => User::OFFICE_ID,
                    'transactionable_type' => User::class,
                    'amount' => $request->amount,
                    'type' => $request->type,
                    'paid_by' => $request->paid_by,
                    'note' => 'Paid for ' . $staff->name . ' ' . $staff->surname . ' salary',
                ]);
            }

            Transaction::create([
                'transactionable_id' => User::OFFICE_ID,
                'transactionable_type' => User::class,
                'amount' => $staff->salary,
                'type' => 'OUT',
                'paid_by' => Transaction::PAID_BY_BANK_TRANSFER,
                'note' => 'Paid for ' . $staff->name . ' ' . $staff->surname . ' official salary',
            ]);

            Transaction::create([
                'transactionable_id' => $staff->id,
                'transactionable_type' => Staff::class,
                'amount' => $staff->salary + $amount,
                'type' => 'IN',
                'paid_by' => $request->paid_by,
                'note' => 'Salary payment for ' . $request->date_range,
            ]);

            if ($request->has('advance_payment_id')) {
                $payment = AdvancePayment::findOrFail($request->advance_payment_id);
                $record = new AdvancePaymentRecord([
                    'amount' => $request->advance_payment_amount,
                    'note' => 'Payment was deducted while forming the salary'
                ]);

                $payment->records()->save($record);
                $payment->remaining_amount = $payment->remaining_amount - $record->amount;
                $payment->touch();
            }

            if ($request->has('bonusIds')) {
                foreach ($request->bonusIds as $bonus_id) {
                    $bonus = Bonus::findOrFail($bonus_id);
                    $bonus->is_paid = 1;
                    $bonus->touch();
                }
            }

            if ($request->has('fineIds')) {
                foreach ($request->fineIds as $fine_id) {
                    $fine = Fine::findOrFail($fine_id);
                    $fine->is_paid = 1;
                    $fine->touch();
                }
            }

            DB::commit();

            return redirect('/staff');
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back();
        }
    }
}
