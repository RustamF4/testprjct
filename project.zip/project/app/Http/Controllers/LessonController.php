<?php

namespace App\Http\Controllers;

use App\Helpers\OptionsMapper;
use App\Helpers\RequestHelper;
use App\Http\Requests\ConfirmLessonAttendanceRequest;
use App\Http\Requests\UpdateAttendanceRecordRequest;
use App\Http\Requests\UpdateLessonRequest;
use App\Models\Attendance;
use App\Models\Extra;
use App\Models\Lesson;
use App\Models\Recovery;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Support;
use App\Models\Teacher;
use App\Models\Transaction;
use App\Rules\StringIsValidDate;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;

class LessonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view lessons'))
        {
            return view('pages.office.blank');
        }

        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
        ]);

        if ($request->filled('date_range'))
        {
            $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);
            $start_time = $dateRange[0];
            $end_time = $dateRange[1];
        }
        else
        {
            $start_time = Carbon::now()->startOfDay()->subDays(3);
            $end_time = Carbon::now()->addMonth();
        }

        $lessons = Lesson::whereBetween('start_time', [$start_time, $end_time]);

        if ($request->confirmed == 'on') {
            $lessons = $lessons->whereAttendanceChecked(1);
        } else {
            $lessons = $lessons->whereAttendanceChecked(0);
        }

        if ($request->filled('teacher_id'))
        {
            $lessons = $lessons
                ->whereTeacherId($request->teacher_id);
        }

        if ($request->filled('subject_id'))
        {
            $lessons = $lessons
                ->whereHas('classtime', function ($query) use ($request) {
                    $query->whereHas('subject', function ($query) use ($request) {
                        $query->where('subjects.id', $request->subject_id);
                    });
                });
        }

        $lessons = $lessons
            ->orderBy('start_time')
            ->with([
                'teacher',
                'classtime' => function ($query) {
                    $query->withTrashed();
                },
                'attendance',
                'attendance.student' => function ($query) {
                    $query->withTrashed();
                },
            ])
            ->paginate(10)
            ->withQueryString();

        $statuses = Attendance::STATUSES;

        return view('pages.office.lessons')->with([
            'teacher_options' => OptionsMapper::MapTeachers(),
            'subject_options' => OptionsMapper::MapSubjects(),
            'lessons' => $lessons,
            'statuses' => $statuses
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateLessonRequest $request
     * @param Lesson $lesson
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateLessonRequest $request, Lesson $lesson)
    {
        $lesson->teacher_id = $request->teacher_id;
        $lesson->touch();

        return redirect()->back()
            ->with('success', 'Lesson updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Lesson $lesson
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Lesson $lesson)
    {
        $lesson->attendance()->delete();
        $lesson->delete();

        return redirect()->back()
            ->with('success', 'Lesson deleted successfully');
    }

    public function markAttendance(Request $request)
    {
        $user = Auth::user() ?? Auth::guard('teacher')->user();

        foreach ($request->records as $record_id) {

            $attendance = Attendance::findOrFail($record_id);

            if ($user->cannot('change other teachers attendance record')
                && ($user->id != $attendance->attendanceable->teacher->id || isset($attendance->status))
            )
            {
                return redirect()->back();
            }

            $attendance->status = $request['status_' . $record_id];
            $attendance->note = $request['note_' . $record_id];
            $attendance->touch();
        }


        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateAttendanceRecordRequest $request
     * @param Attendance $attendance
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateAttendanceRecord(UpdateAttendanceRecordRequest $request, Attendance $attendance)
    {
        $user = Auth::user() ?? Auth::guard('teacher')->user();

        if ($user->cannot('change other teachers attendance record')
                && ($user->id != $attendance->attendanceable->teacher->id || isset($attendance->status))
            )
        {
            return redirect()->back();
        }

        $attendance->status = $request->status;
        $attendance->note = $request->note;
        $attendance->touch();

        return redirect()->back()->with('updated_lesson_id', $attendance->attendanceable_id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param ConfirmLessonAttendanceRequest $request
     * @param int $lessonId
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function confirmLessonsAttendance(ConfirmLessonAttendanceRequest $request, int $lessonId)
    {
        DB::beginTransaction();

        try
        {
            $lesson = null;
            $amount = 0;
            $subject_id = null;
            $lesson_type = $request->lesson_type;

            switch ($lesson_type) {
                case 'lesson':
                    $lesson = Lesson::with(['classTime', 'attendance', 'teacher'])->findOrFail($lessonId);
                    $subject_id = $lesson->classTime->subject->id;
                    break;
            }

            if (!isset($lesson) || !isset($subject_id)) {
                return redirect()->back();
            }

            $attendance_records = $lesson->attendance;

            foreach ($attendance_records as $record) {

                if ($lesson_type == 'lesson') {
                    $amount = $record->student->groups()->where('groups.subject_id', $subject_id)
                        ->first()->pivot->price;
                }

                if ($record->status == Attendance::STATUS_PRESENT_FREE ||
                    $record->status == Attendance::STATUS_ABSENT_EXCUSED)
                {
                    $currentAmount = 0;
                }
                else {
                    $currentAmount = $amount;
                }

                Transaction::create([
                    'transactionable_id' => $record->student->id,
                    'transactionable_type' => Student::class,
                    'referencable_id' => $record->id,
                    'referencable_type' => Attendance::class,
                    'subject_id' => $subject_id,
                    'amount' => $currentAmount,
                    'type' => 'OUT',
                    'note' => 'Deducted for attending '
                        . $lesson_type
                        . ' at ' . $lesson->start_time->format('M d, Y H:i')
                        . '. Attendance Status: ' . $record->status,
                ]);

                Transaction::create([
                    'transactionable_id' => $lesson->teacher->id,
                    'transactionable_type' => Teacher::class,
                    'referencable_id' => $record->id,
                    'referencable_type' => Attendance::class,
                    'subject_id' => $subject_id,
                    'amount' => $currentAmount,
                    'type' => 'IN',
                    'note' => 'Added to turnover because student '
                        . $record->student->name . ' ' . $record->student->surname . ' attended '
                        . $lesson_type
                        . ' at ' . $lesson->start_time->format('M d, Y H:i')
                        . '. Attendance Status: ' . $record->status,
                ]);
            }

            $lesson->attendance_checked = true;
            $lesson->touch();

            DB::commit();

            return redirect()->back()
                ->with('updated_lesson_id', $lesson->id);
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back()
                ->with('error', $e->getMessage());
        }
    }

    /**
     * Rollback Attendance Record
     *
     * @param ConfirmLessonAttendanceRequest $request
     * @param int $lessonId
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function rollbackAttendanceConfirm(ConfirmLessonAttendanceRequest $request, int $lessonId)
    {
        DB::beginTransaction();

        try
        {
            $lesson_type = $request->lesson_type;

            switch ($lesson_type) {
                case 'lesson':
                    $lesson = Lesson::with(['attendance'])->findOrFail($lessonId);
                    break;
                case 'support':
                    $lesson = Support::with(['attendance'])->findOrFail($lessonId);
                    break;
                case 'extra':
                    $lesson = Extra::with(['attendance'])->findOrFail($lessonId);
                    break;
                case 'recovery':
                    $lesson = Recovery::with(['attendance'])->findOrFail($lessonId);
            }

            if (!isset($lesson)) {
                return redirect()->back();
            }

            $attendance_records = $lesson->attendance;

            foreach ($attendance_records as $record) {
                Transaction::where([
                    'referencable_id' => $record->id,
                    'referencable_type' => Attendance::class,
                ])->delete();
            }

            $lesson->attendance_checked = false;
            $lesson->touch();

            DB::commit();

            return redirect()->back()
                ->with('updated_lesson_id', $lesson->id);
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back()
                ->with('error', $e->getMessage());
        }
    }
}
