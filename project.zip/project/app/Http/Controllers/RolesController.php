<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateRoleRequest;
use App\Http\Requests\UpdateRoleRequest;
use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Models\Role;

class RolesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index()
    {
        $user = Auth::user();

        if ($user->cannot('view roles'))
        {
            return view('pages.office.blank');
        }

        $roles = Role::whereGuardName('web')
            ->paginate(10)
            ->withQueryString();

        return view('pages.office.roles')->with([
            'roles' => $roles
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  CreateRoleRequest $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateRoleRequest $request)
    {
        $role = Role::create([
            'name' => $request->name
        ]);

        $role->givePermissionTo($request->permissions);


        return redirect()->back()
            ->with('success', 'Role has been created successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateRoleRequest $request
     * @param  Role $role
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRoleRequest $request, Role $role)
    {
        $role->name = $request->name;
        $role->syncPermissions($request->permissions);

        $role->touch();

        return redirect()->back()
            ->with('success', 'Student updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Role $role
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Role $role)
    {
        $role->delete();

        return redirect()->back()
            ->with('success', 'Role deleted successfully');
    }
}
