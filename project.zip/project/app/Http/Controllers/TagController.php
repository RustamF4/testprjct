<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tag;
use Illuminate\Support\Facades\Validator;

class TagController extends Controller
{
    public function store(Request $request)
    {
        Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:tags',
        ])->validate();

        $tag = Tag::create([
            'name' => $request->name
        ]);

        return response()->json([
            'message' => 'Tag created successfully',
            'tag' => $tag
        ]);
    }
}

