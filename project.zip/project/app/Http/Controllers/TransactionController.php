<?php

namespace App\Http\Controllers;

use App\Helpers\OptionsMapper;
use App\Helpers\RequestHelper;
use App\Http\Requests\AdjustSubjectBalanceRequest;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Tag;
use App\Models\Teacher;
use App\Models\Transaction;
use App\Models\User;

use App\Rules\StringIsValidDate;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Carbon\Carbon;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view transactions'))
        {
            return view('pages.office.blank');
        }

        $request->validate([
            'date_range' => [
                'nullable',
                'string',
                'max:30',
                new StringIsValidDate
            ],
            'paid_by' => [
                'nullable',
                'in:CASH,C2C,POS,BANK_TRANSFER'
            ],
            'subject_id' => [
                'nullable',
                'exists:subjects,id'
            ],
            'student_id' => [
                'nullable',
                'exists:students,id'
            ],
            'teacher_id' => [
                'nullable',
                'exists:teachers,id'
            ],
            'tag_id' => [
                'nullable',
                'exists:tags,id'
            ]
        ]);

        if ($request->filled('date_range'))
        {
            $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);
            $start_time = $dateRange[0];
            $end_time = $dateRange[1];
        }
        else
        {
            $start_time = Carbon::now()->subMonth();
            $end_time = Carbon::now()->addDay();
        }

        $transactions = Transaction::whereBetween('created_at', [$start_time, $end_time]);

        if ($request->filled('office_only'))
        {
            $transactions = $transactions
                ->whereTransactionableType(User::class)
                ->whereTransactionableId(User::OFFICE_ID);
        }

        if ($request->filled('paid_by'))
        {
            $transactions = $transactions->wherePaidBy($request->paid_by);
        }

        if ($request->filled('student_id'))
        {
            $transactions = $transactions
                ->whereTransactionableType(Student::class)
                ->whereTransactionableId($request->student_id);
        }

        if ($request->filled('teacher_id'))
        {
            $transactions = $transactions
                ->whereTransactionableType(Teacher::class)
                ->whereTransactionableId($request->teacher_id);
        }

        if ($request->filled('subject_id'))
        {
            $transactions = $transactions
                ->whereSubjectId($request->subject_id);
        }

        if ($request->filled('tag_id'))
        {
            $tagId = $request->tag_id;
            $transactions = $transactions->whereHas('tags', function ($query) use ($tagId) {
                $query->where('id', $tagId);
            });
        }

        $transactions = $transactions
            ->with([
                'transactionable',
                'subject',
            ])
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $paid_byes = Transaction::TRANSACTION_TYPES;

        return view('pages.office.transactions')->with([
            'transactions' => $transactions,
            'paid_byes' => $paid_byes,
            'teacher_options' => OptionsMapper::MapTeachers(),
            'subject_options' => OptionsMapper::MapSubjects(),
            'student_options' => OptionsMapper::MapStudents(),
            'tag_options' => OptionsMapper::MapTags()
        ]);
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        try
        {
            $request->validate([
                'amount' => 'required|numeric|min:0',
                'type' => 'required|in:IN,OUT',
                'paid_by' => 'required|in:CASH,C2C,POS,BANK_TRANSFER',
                'note' => 'nullable|string',
                'tags_ids' => 'nullable|string'
            ]);

            $transaction = new Transaction([
                'transactionable_id' => User::OFFICE_ID,
                'transactionable_type' => User::class,
                'amount' => $request->amount,
                'type' => $request->type,
                'paid_by' => $request->paid_by,
                'note' => $request->note,
            ]);

            $transaction->save();

            if ($request->has('tags_ids') && $request->tags_ids != '') {
                $tagsIdsArray = explode(',', $request->tags_ids);

                foreach ($tagsIdsArray as $tagId) {
                    if (Tag::where('id', $tagId)->exists()) {
                        redirect()->back()->with('error', 'Tag Id does not exist');
                    }
                }
                $transaction->tags()->attach($tagsIdsArray);
            }
            DB::commit();

            return redirect()->back()->with('success', 'Transaction created successfully.');
        }
        catch (\Exception $e)
        {
            DB::rollback();

            return redirect()->back()
                ->with('error', $e->getMessage());
        }
    }

    public function getChartDataAjax(Request $request)
    {
        $user = User::with('transactions')->findOrFail(User::OFFICE_ID);
        $period = $request->input('period', 'daily');
        $count = 6;

        $chartData = $this->getChartData($user, $period, $count);

        return response()->json($chartData);
    }


    private function getChartData($user, $period, $count)
    {
        $incomeData = [];
        $expensesData = [];

        for ($i = $count - 1; $i >= 0; $i--) {
            $date = Carbon::now();
            $formattedDate = '';

            switch ($period) {
                case 'daily':
                    $date->subDays($i);
                    $startPeriod = $date->copy()->startOfDay();
                    $endPeriod = $date->copy()->endOfDay();

                    $formattedDate = $date->format('F j');
                    break;
                case 'weekly':
                    $date->subWeeks($i);
                    $startPeriod = $date->copy()->startOfWeek();
                    $endPeriod = $date->copy()->endOfWeek();

                    $startOfWeek = $date->startOfWeek()->format('F j');
                    $endOfWeek = $date->endOfWeek()->format('j');
                    $formattedDate = $startOfWeek . '-' . $endOfWeek;
                    break;
                case 'monthly':
                    $date->subDays($i * 30);
                    $startPeriod = $date->copy()->startOfMonth();
                    $endPeriod = $date->copy()->endOfMonth();

                    $formattedDate = $date->format('F Y');
                    break;
            }

            $income = $user->transactions
                ->where('type', 'IN')
                ->whereBetween('created_at', [$startPeriod, $endPeriod])
                ->sum('amount');

            $expense = $user->transactions
                ->where('type', 'OUT')
                ->whereBetween('created_at', [$startPeriod, $endPeriod])
                ->sum('amount');

            $incomeData[] = ['x' => $formattedDate, 'y' => number_format($income, '2')];
            $expensesData[] = ['x' => $formattedDate, 'y' => number_format($expense, '2')];
        }

        return [
            'income' => $incomeData,
            'expenses' => $expensesData
        ];
    }

    public function student_top_up(AdjustSubjectBalanceRequest $request)
    {
        $student = Student::findOrFail($request->student_id);
        $subject = Subject::findOrFail($request->subject_id);

        Transaction::create([
            'transactionable_id' => $student->id,
            'transactionable_type' => Student::class,
            'subject_id' => $subject->id,
            'amount' => $request->amount,
            'type' => $request->type,
            'paid_by' => $request->paid_by,
            'note' => $request->note,
        ]);

        if ($request->effect_office == 'on') {
            $transactionNote = $request->type == 'IN'
                ? $student->name . ' ' . $student->surname . ' topped up the balance for ' . $subject->name
                : $student->name . ' ' . $student->surname . ' withdraw balance from ' . $subject->name;

            Transaction::create([
                'transactionable_id' => User::OFFICE_ID,
                'transactionable_type' => User::class,
                'subject_id' => $request->subject_id,
                'amount' => $request->amount,
                'type' => $request->type,
                'paid_by' => $request->paid_by,
                'note' => $transactionNote,
            ]);
        }

        return redirect()->back()
            ->with([
                'updated_student_id_group' => $student->id,
                'updated_group_id_student' => $request->group_id,
            ]);
    }

    public function generateReport(Request $request) {

        $request->validate([
            'date_range' => [
                'required',
                'string',
                'max:30',
                new StringIsValidDate
            ],
        ]);

        $dateRange = RequestHelper::FetchDateRangeFromString($request->date_range);
        $startDate = $dateRange[0];
        $endDate = $dateRange[1];

        $office = User::with('transactions')->findOrFail(User::OFFICE_ID);
        $paid_by_types = Transaction::TRANSACTION_TYPES;
        $paidByes = [];
        $totalIncome = 0;
        $totalExpense = 0;

        foreach ($paid_by_types as $name => $paid_by) {

            $incomeAmount = $office->getPaidByIncomeInTimeSpan($name, $startDate, $endDate);
            $expenseAmount = $office->getPaidByExpenseInTimeSpan($name, $startDate, $endDate);

            $paidByes[] = [
                "name" => $name,
                "income_amount" => number_format($incomeAmount, 2) . ' ₼',
                "income_icon" => 'fa-duotone fa-' . $paid_by['icon'] . ' text-success',
                "expense_amount" => number_format($expenseAmount, 2) . ' ₼',
                "expense_icon" => 'fa-duotone fa-' . $paid_by['icon'] . ' text-error',
            ];

            $totalIncome += $incomeAmount;
            $totalExpense += $expenseAmount;
        }

        $divideBy = $totalIncome == 0 ? 1 : $totalIncome;

        $data = [
            "paid_byes" => $paidByes,
            "total_income" => number_format($totalIncome, 2) . ' ₼',
            "income_icon" => "fa-duotone fa-chart-line-up text-success",
            "total_expense" => number_format($totalExpense, 2) . ' ₼',
            "expense_icon" => "fa-duotone fa-chart-line-down text-error",
            "net_icon" => "fa-duotone fa-money-bill-trend-up text-success",
            "net_amount" => number_format($totalIncome - $totalExpense, 2) . ' ₼',
            "net_percent_icon" => "fa-duotone fa-hundred-points text-success",
            "net_percent" => number_format((($totalIncome - $totalExpense) / $divideBy) * 100, 2) . '%'
        ];

        return view('pages.office.transactions-report')->with([
            'data' => $data
        ]);
    }
}
