<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateSubjectRequest;
use App\Http\Requests\DeleteSubjectRequest;
use App\Http\Requests\UpdateSubjectRequest;
use App\Models\Subject;
use Auth;
use Fuse\Fuse;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Contracts\View\Factory
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        if ($user->cannot('view subjects'))
        {
            return view('pages.office.blank');
        }

        $query = $request->input('search');

        $subjects = Subject::with([
            'groups' => function ($query) {
                $query->with('teacher')->withCount('students');
            }
        ]);

        if (!empty($query)) {
            $fuse = new Fuse($subjects->get()->toArray(), [
                'keys' => ['name', 'year'],
                'threshold' => 0.3,
            ]);

            $results = $fuse->search($query);

            $subjectIds = array_filter(array_map(function ($result) {
                return $result['item']['id'] ?? null;
            }, $results));

            $subjects = Subject::whereIn('id', $subjectIds);
        }

        $subjects = $subjects
            ->paginate(10)
            ->withQueryString();

        return view('pages.office.subjects')->with([
            'subjects' => $subjects,
            'query' => $query
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  CreateSubjectRequest $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateSubjectRequest $request)
    {
        Subject::create([
            'name' => $request->name,
            'year' => $request->year,
        ]);

        return redirect()->back()
            ->with('success', 'Subject created successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  UpdateSubjectRequest $request
     * @param  Subject $subject
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateSubjectRequest $request, Subject $subject)
    {
        $subject->name = $request->name;
        $subject->year = $request->year;

        $subject->touch();

        return redirect()->back()
            ->with('success', 'Subject updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  DeleteSubjectRequest $request
     * @param  Subject $subject
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(DeleteSubjectRequest $request, Subject $subject)
    {
        $subject->archive_reason = $request->archive_reason;
        $subject->touch();
        $subject->delete();

        return redirect()->back()
            ->with('success', 'Subject deleted successfully');
    }
}
