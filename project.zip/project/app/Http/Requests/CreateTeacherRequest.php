<?php

namespace App\Http\Requests;

use Auth;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;

class CreateTeacherRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = Auth::user();
        return $user->can('create teacher');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'email' => 'required|email|unique:teachers|max:255',
            'phone' => 'required|string|max:255',
            'salary' => 'nullable|numeric',
            'actual_salary' => 'nullable|numeric|gte:salary',
            'salary_per_lesson' => 'nullable|numeric|min:0',
            'referred_by' => 'nullable|string|max:255',
            'password' => ['required', 'confirmed',  Rules\Password::defaults()]
        ];
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param  \Illuminate\Contracts\Validation\Validator  $validator
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        $errors->add('create_teacher_form', 'Create Teacher Form - Validation Failed');

        parent::failedValidation($validator);
    }
}
