<?php

namespace App\Http\Requests;

use Auth;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class AdjustSubjectBalanceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = Auth::user();
        return $user->can('edit student subject balance');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'subject_id' => 'required|exists:subjects,id',
            'student_id' => 'required|exists:students,id',
            'group_id' => 'required|exists:groups,id',
            'effect_office' => 'nullable|in:on',
            'type' => 'required|in:IN,OUT',
            'amount' => 'required|numeric|min:1',
            'paid_by' => 'required|in:CASH,C2C,POS,BANK_TRANSFER',
            'note' => 'nullable|string',
        ];
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param  \Illuminate\Contracts\Validation\Validator  $validator
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        $errors->add(
            'student_top_up_form_' . $this->student_id . '_' . $this->subject_id,
            'Student Top Up Form - Validation Failed'
        );

        parent::failedValidation($validator);
    }
}
