<?php

namespace App\Http\Requests;

use Auth;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class UpdateStudentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = Auth::user();
        return $user->can('edit student');
    }

    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'middle_name' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:255',
            'phone' => 'required|string|max:255',
            'info' => 'nullable|string',
            'year' => 'nullable|integer|min:0|max:12',
            'school' => 'nullable|string|max:255',
            'referred_by' => 'nullable|string|max:255',
        ];
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param  \Illuminate\Contracts\Validation\Validator  $validator
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        $errors->add(
            'update_student_form_' . $this->route('student')->id,
            'Update Student Form - Validation Failed'
        );

        parent::failedValidation($validator);
    }
}
