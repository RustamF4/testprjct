<?php

namespace App\Http\Requests;

use App\Models\ClassTime;
use Auth;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class UpdateClassTimeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = Auth::user();
        return $user->can('edit group classtime');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $groupId = $this->route('classTime')->group->id;

        return [
            'weekday' => ['required', "in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday"],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time', function ($attribute, $value, $fail)
            use ($groupId) {
                $existingClassTime = ClassTime::where('group_id', $groupId)
                    ->where('weekday', $this->input('weekday'))
                    ->where('start_time', $this->input('start_time'))
                    ->where('end_time', $value)
                    ->first();

                if ($existingClassTime) {
                    $fail('A class time with the same weekday, start time, and end time already exists in the
                        specified group.');
                }
            }
            ]
        ];
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param  \Illuminate\Contracts\Validation\Validator  $validator
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        $errors->add(
            'update_class_time_form_' . $this->route('classTime')->id,
            'Update Class Time Form - Validation Failed'
        );

        parent::failedValidation($validator);
    }
}
