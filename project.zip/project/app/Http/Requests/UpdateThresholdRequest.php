<?php

namespace App\Http\Requests;

use Auth;
use DB;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateThresholdRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = Auth::user();
        return $user->can('edit salary threshold');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $thresholdId = $this->route('threshold')->id;
        $teacherId = $this->route('threshold')->teacher_id;

        return [
            'has_no_limit' => [
                'nullable',
                'in:on',
                function ($attribute, $value, $fail) use ($teacherId, $thresholdId) {
                    $exists = DB::table('thresholds')
                        ->where('teacher_id', $teacherId)
                        ->where('id', '!=' , $thresholdId)
                        ->whereNull('turnover')
                        ->exists();
                    if ($exists) {
                        $fail('You already have an unlimited threshold for this teacher.');
                    }
                },
            ],
            'turnover' => [
                'nullable',
                'required_without:has_no_limit',
                'numeric',
                'min:0',
                'max:1000000',
                Rule::unique('thresholds', 'turnover')
                    ->whereNot('id', $thresholdId)
                    ->where('teacher_id', $teacherId),
            ],
            'is_fixed' => 'nullable|in:on',
            'amount' => [
                'nullable',
                'required_if:is_fixed,=,on',
                'numeric',
                'min:0',
                function ($attribute, $value, $fail) {
                    if (request()->filled('turnover') && $value > request()->input('turnover')) {
                        $fail('The '.$attribute.' must be less than or equal to the turnover.');
                    }
                }
            ],
            'percent' => 'nullable|required_without:is_fixed|numeric|min:0|max:100',
        ];
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param  \Illuminate\Contracts\Validation\Validator  $validator
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        $errors->add(
            'update_teacher_threshold_form_' . $this->route('threshold')->id,
            'Update Teacher Threshold Form - Validation Failed'
        );

        parent::failedValidation($validator);
    }
}
