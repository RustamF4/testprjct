<?php

namespace App\Rules;

use Carbon\Carbon;
use Carbon\Exceptions\InvalidFormatException;
use Illuminate\Contracts\Validation\Rule;

class StringIsValidDate implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value): bool
    {
        $dataRange = explode(" to ", $value);

        if (sizeof($dataRange) == 1) {
            $dataRange[1] = $dataRange[0];
        }

        try {
            $startDate = Carbon::parse($dataRange[0]);
            $endDate = Carbon::parse($dataRange[1]);
        }
        catch (InvalidFormatException $e) {
            return false;
        }

        return $startDate->lessThanOrEqualTo($endDate);
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message(): string
    {
        return 'The end date must be greater than or equal to the start date.';
    }
}
