<?php


namespace App\Helpers;


use Carbon\Carbon;


class RequestHelper
{
    public static function FetchDateRangeFromString(string $requestDateRange) : array
    {
        $dataRange = explode(" to ", $requestDateRange);

        if (sizeof($dataRange) == 1) {
            $dataRange[1] = $dataRange[0];
        }

        $dataRange[0] = Carbon::parse($dataRange[0])->startOfDay();
        $dataRange[1] = Carbon::parse($dataRange[1])->endOfDay();

        return $dataRange;
    }
}
