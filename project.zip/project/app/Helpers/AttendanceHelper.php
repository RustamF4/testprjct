<?php

namespace App\Helpers;


use App\Models\Attendance;
use App\Models\ClassTime;
use App\Models\Group;
use App\Models\Lesson;
use App\Models\Student;
use App\Models\Support;
use Carbon\Carbon;


class AttendanceHelper
{
    public static function GenerateAttendanceForAllStudentsInLesson(Lesson $lesson, $studentIds)
    {
        foreach ($studentIds as $studentId) {
            self::GenerateAttendanceForStudentByType(Lesson::class,$lesson->id, $studentId);
        }
    }

    public static function GenerateAttendanceForNewStudent(Group $group, $studentId)
    {
        $classTimes = $group->classTimes;

        foreach ($classTimes as $classTime) {
            self::GenerateAttendanceForClassTime($classTime, $studentId);
        }
    }

    public static function GenerateAttendanceForClassTime(ClassTime $classTime, $studentId)
    {
        $lessons = $classTime->lessons()->where('start_time', '>=', Carbon::now())->get();

        foreach ($lessons as $lesson) {
            self::GenerateAttendanceForStudentByType(Lesson::class, $lesson->id, $studentId);
        }
    }

    public static function GenerateAttendanceForStudentByType($lessonType, $lessonId, $studentId)
    {
        Attendance::create([
            'attendanceable_type' => $lessonType,
            'attendanceable_id' => $lessonId,
            'student_id' => $studentId,
        ]);
    }

    public static function DeleteAttendanceForStudentByType($lessonType, $lessonId, $studentId)
    {
        Attendance::where('attendanceable_type', $lessonType)
            ->where('attendanceable_id', $lessonId)
            ->where('student_id', $studentId)
            ->delete();
    }


    public static function DeleteLessonsFutureAttendance($lessonIds)
    {
        Attendance::where('attendanceable_type', Lesson::class)
            ->whereIn('attendanceable_id', $lessonIds)
            ->delete();
    }

    public static function  DeleteStudentsFutureAttendanceForClassTime(ClassTime $classTime, $studentId)
    {
        $lessons = $classTime->lessons()->where('start_time', '>=', Carbon::now())->get();
        $lessonIds = $lessons->pluck('id')->toArray();

        Attendance::where('attendanceable_type', Lesson::class)
            ->where('student_id', $studentId)
            ->whereIn('attendanceable_id', $lessonIds)
            ->delete();
    }

    public static function GenerateWeeklyTimetable($lessons)
    {
        // Initialize the dictionary to store lessons mapped to weekdays
        $timetable = collect();

        // Loop through each lesson and map it to the corresponding weekday
        foreach ($lessons as $lesson) {
            $weekday = Carbon::parse($lesson->start_time)->format('l');
            $timetable->put($weekday, $timetable->get($weekday, collect())->push($lesson));
        }

        return $timetable;
    }
}
