<?php

namespace App\Helpers;

use Carbon\Carbon;

class DateHelper
{
    public static function getThisWeekBoundaries(): array
    {
        // Get the current date
        $today = Carbon::now();

        // Get the start and end of the current week (Monday to Sunday)
        $startOfWeek = $today->copy()->startOfWeek()->addWeek();
        $endOfWeek = $today->copy()->endOfWeek()->addWeek();

        return [$startOfWeek, $endOfWeek];
    }
}

