<?php

namespace App\Helpers;


use App\Models\Lesson;
use App\Models\Group;
use App\Models\ClassTime;

use Carbon\Carbon;


class LessonHelper
{
    public static function GenerateLessons(Group $group)
    {
        $classTimes = $group->classTimes;

        foreach ($classTimes as $classTime) {
            self::RegenerateLessonForClassTime($group, $classTime);
        }
    }

    public static function RegenerateLessonForClassTime(Group $group, ClassTime $classTime)
    {
        self::DeleteFutureLessons($classTime);

        self::GenerateLessonsForClassTime($group, $classTime);
    }

    public static function DeleteFutureLessons(ClassTime $classTime)
    {
        $lessons = $classTime->lessons()->where('start_time', '>=', Carbon::now())->get();

        $lessonIds = $lessons->pluck('id')->toArray();

        // Delete future attendance records of lessons for this class time only
        AttendanceHelper::DeleteLessonsFutureAttendance($lessonIds);

        // Delete future lessons for this class time only
        Lesson::whereIn('id', $lessonIds)->delete();
    }

    public static function GenerateLessonsForClassTime(Group $group, ClassTime $classTime)
    {
        $studentIds = $classTime->students->pluck('id')->toArray();
        $lessonDate = $group->starts_at->isPast() ? Carbon::now() : $group->starts_at;

        $map = [
            'Sunday' => 0,
            'Monday' => 1,
            'Tuesday' => 2,
            'Wednesday' => 3,
            'Thursday' => 4,
            'Friday' => 5,
            'Saturday' => 6,
        ];

        $lessonDateOfWeek = $lessonDate->dayOfWeek;
        $targetDayOfWeek = $map[$classTime->weekday];
        $minLessonStart = Carbon::parse($lessonDate->toDateString()
            . ' ' . $classTime->start_time->format('H:i')
        );

        if ($lessonDateOfWeek !== $targetDayOfWeek || $minLessonStart->isPast()) {
            $lessonDate = $lessonDate->next($classTime->weekday);
        }

        while ($lessonDate <= $group->ends_at) {
            $lessonStart = Carbon::parse($lessonDate->toDateString() . ' ' . $classTime->start_time->format('H:i'));
            $lessonEnd = Carbon::parse($lessonDate->toDateString() . ' ' . $classTime->end_time->format('H:i'));

            $lesson = Lesson::create([
                'start_time' => $lessonStart,
                'end_time' => $lessonEnd,
                'class_time_id' => $classTime->id,
                'teacher_id' => $group->teacher->id,
            ]);

            AttendanceHelper::GenerateAttendanceForAllStudentsInLesson($lesson, $studentIds);

            $lessonDate = $lessonDate->next($classTime->weekday);
        }
    }
}
