<?php


namespace App\Helpers;



use App\Models\Lesson;
use App\Models\Staff;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Tag;
use App\Models\Teacher;

class OptionsMapper
{
    public static function MapStaff()
    {
        return Staff::all()->map(function($staff) {
            return [
                'value' => $staff->id,
                'text' =>
                    $staff->name
                    . ' ' .
                    $staff->surname
            ];
        });
    }

    public static function MapTeachers()
    {
        return Teacher::all()->map(function($teachers) {
            return [
                'value' => $teachers->id,
                'text' =>
                    $teachers->name
                    . ' ' .
                    $teachers->surname
            ];
        });
    }

    public static function MapSubjects()
    {
        return Subject::all()->map(function($subject) {
            return [
                'value' => $subject->id,
                'text' => $subject->name
            ];
        });
    }

    public static function MapStudents()
    {
        return Student::all()->map(function($student) {
            return [
                'value' => $student->id,
                'text' =>
                    $student->name
                    . ' ' .
                    $student->surname
                    . ' ' .
                    $student->middle_name
            ];
        });
    }

    public static function MapLessons()
    {
        $lessons = Lesson::orderBy('start_time')
            ->with([
                'classtime' => function ($query) {
                    $query->withTrashed()->orderBy('weekday', 'asc')->orderBy('start_time', 'asc');
                },
                'teacher' => function ($query) {
                    $query->withTrashed();
                },
            ])
            ->get();

        return $lessons->map(function($lesson) {
            return [
                'value' => $lesson->id,
                'text' =>
                    $lesson->start_time->format('l, M d, Y H:i')
                    . ' | ' .
                    $lesson->teacher->name
                    . ' ' .
                    $lesson->teacher->surname
            ];
        });
    }

    public static function MapTags()
    {
        return Tag::all()->map(function($tag) {
            return [
                'value' => $tag->id,
                'text' => $tag->name
            ];
        });
    }
}
